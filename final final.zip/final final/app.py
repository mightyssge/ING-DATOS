from flask import Flask, render_template, request, redirect, url_for
import cx_Oracle

app = Flask(__name__)

# Conexión a la base de datos
username = "USERDB"
password = "PASSWORD"
host = 'localhost'
port = '1521'
connection_str = f"{username}/{password}@{host}:{port}/xe"

try:
    conn = cx_Oracle.connect(connection_str)
    print("Conexión exitosa")
except cx_Oracle.Error as err:
    print(f"Error de conexión {err}")

# Ruta para mostrar los vehículos
@app.route('/cliente-2')
def cliente_2():
    # Obtener vehículos desde la base de datos (reemplazar con tu lógica)
    vehiculos = obtener_vehiculos_desde_bd()
    
    return render_template('Cliente - 2.html', vehiculos=vehiculos)

# Ruta para mostrar detalles del vehículo seleccionado
@app.route('/cliente-3')
def cliente_3():
    # Obtener parámetros de la URL
    marca = request.args.get('marca')
    modelo = request.args.get('modelo')
    anio = request.args.get('anio')
    precio = request.args.get('precio')
    kilometraje = request.args.get('kilometraje')

    # Agregar más parámetros según sea necesario
    # Redirigir a Cliente - 3.html con los parámetros
    return render_template('Cliente - 3.html', marca=marca, modelo=modelo, anio=anio, precio=precio, kilometraje=kilometraje)


# Función para obtener vehículos desde la base de datos
def obtener_vehiculos_desde_bd():
    # Ejemplo de consulta (reemplazar con tu consulta real)
    cursor = conn.cursor()
    cursor.execute("SELECT Marca, Modelo, Anio, Precio, Kilometraje, ImgURL_Vehiculo FROM Vehiculo WHERE ROWNUM <= 7")
    vehiculos = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
    cursor.close()

    return vehiculos

if __name__ == '__main__':
    app.run(debug=True)
