-- Tabla de tipos de mantenimiento
CREATE TABLE TipoMantenimiento (
    Tipo NUMBER PRIMARY KEY,
    Descripcion CLOB
);

-- Tabla de almacen
CREATE TABLE Almacen (
    ID_Almacen NUMBER PRIMARY KEY,
    Ubicacion VARCHAR2(255),
    CapacidadV NUMBER,
    CantidadV NUMBER,
    IMGURL_Almacen VARCHAR2(255)
);

-- Tabla de empresa
CREATE TABLE Empresa (
    RUC NUMBER PRIMARY KEY,
    Dominio_Fiscal VARCHAR2(200),
    Nombre VARCHAR2(200)
);

-- Tabla de notaria
CREATE TABLE Notaria (
    ID_Notaria NUMBER PRIMARY KEY,
    Nombre VARCHAR2(200),
    Direccion VARCHAR2(200)
);

-- Tabla de vendedor
CREATE TABLE Vendedor (
    ID_Empleado NUMBER PRIMARY KEY,
    Telefono VARCHAR2(200),
    Email VARCHAR2(200),
    Nombre VARCHAR2(200),
    Apellido VARCHAR2(200),
    Salario NUMBER,
    RUC NUMBER,
    ID_Almacen NUMBER,
    FOREIGN KEY (RUC) REFERENCES Empresa(RUC),
    FOREIGN KEY (ID_Almacen) REFERENCES Almacen(ID_Almacen)
);

-- Tabla de banco
CREATE TABLE Banco (
    ID_BANCO NUMBER PRIMARY KEY,
    Nombre VARCHAR2(200),
    Ubicacion VARCHAR2(255),
    IMGURL_Banco VARCHAR2(255)
);

-- Tabla de vehiculo
CREATE TABLE Vehiculo (
    NroChasis NUMBER PRIMARY KEY,
    Modelo VARCHAR2(255),
    Placa VARCHAR2(255),
    Estado VARCHAR2(255),
    Anio NUMBER,
    Precio NUMBER(10,2),
    FechaIngreso DATE,
    FechaSalida DATE,
    ImgURL_Vehiculo VARCHAR2(255),
    Kilometraje NUMBER,
    Combustible NUMBER,
    Condicion NUMBER,
    Marca VARCHAR2(255),
    Transmision NUMBER,
    NroMotor NUMBER,
    Color VARCHAR2(255),
    ID_Almacen NUMBER,
    RUC NUMBER,
    FOREIGN KEY (ID_Almacen) REFERENCES Almacen(ID_Almacen),
    FOREIGN KEY (RUC) REFERENCES Empresa(RUC)
);



-- Tabla de cliente
CREATE TABLE Cliente (
    DNI NUMBER PRIMARY KEY,
    Email VARCHAR2(255),
    Nombre VARCHAR2(100),
    Apellido VARCHAR2(100),
    Estatus VARCHAR2(50),
    IntencionCompra NUMBER,
    TiempoIngresoLead TIMESTAMP,
    TiempoSalidaLead TIMESTAMP,
    ID_Almacen NUMBER,
    ID_Empleado NUMBER,
    FOREIGN KEY (ID_Almacen) REFERENCES Almacen(ID_Almacen),
    FOREIGN KEY (ID_Empleado) REFERENCES Vendedor(ID_Empleado)
);

-- Tabla de cita
CREATE TABLE Cita (
    ID_Cita NUMBER PRIMARY KEY,
    Proposito VARCHAR2(255),
    Descripcion VARCHAR2(1000),
    FechaCita DATE,
    Asistencia VARCHAR2(1),
    ID_Empleado NUMBER,
    ID_Almacen NUMBER,
    DNI NUMBER,
    FOREIGN KEY (ID_Empleado) REFERENCES Vendedor(ID_Empleado),
    FOREIGN KEY (ID_Almacen) REFERENCES Almacen(ID_Almacen),
    FOREIGN KEY (DNI) REFERENCES Cliente(DNI)
);

-- Tabla de transferencia bancaria
CREATE TABLE TransferenciaBancaria (
    ID_TransfBanc NUMBER PRIMARY KEY,
    Importe NUMBER,
    FechaTransaccion DATE,
    ID_Banco NUMBER,
    DNI NUMBER,
    ID_Vehiculo NUMBER,
    ID_Empleado NUMBER,
    FOREIGN KEY (ID_Banco) REFERENCES Banco(ID_Banco),
    FOREIGN KEY (DNI) REFERENCES Cliente(DNI),
    FOREIGN KEY (ID_Vehiculo) REFERENCES Vehiculo(NroChasis),
    FOREIGN KEY (ID_Empleado) REFERENCES Vendedor(ID_Empleado)
);

-- Tabla de acta de entrega
CREATE TABLE ActaEntrega (
    ID_Acta NUMBER PRIMARY KEY,
    Fecha_Emision DATE,
    RUC NUMBER,
    ID_Notaria NUMBER,
    NroChasis NUMBER,
    DNI NUMBER,
    FOREIGN KEY (ID_Notaria) REFERENCES Notaria(ID_Notaria),
    FOREIGN KEY (RUC) REFERENCES Empresa(RUC),
    FOREIGN KEY (NroChasis) REFERENCES Vehiculo(NroChasis),
    FOREIGN KEY (DNI) REFERENCES Cliente(DNI)
);

-- Tabla de mantenimiento
CREATE TABLE Mantenimiento (
    ID_Mantenimiento NUMBER PRIMARY KEY,
    Fecha_Mantenimiento DATE,
    NroChasis NUMBER,
    Tipo NUMBER,
    FOREIGN KEY (NroChasis) REFERENCES Vehiculo(NroChasis),
    FOREIGN KEY (Tipo) REFERENCES TipoMantenimiento(Tipo)
);

INSERT INTO Almacen (ID_Almacen, Ubicacion, CapacidadV, CantidadV, IMGURL_Almacen)
VALUES (1, 'C. Francisco Masias 2832, San Isidro 15046, Peru', 80, 3, 'https://www.arinfer.com/images/Productos/Portales/playa-javier-prado---los-portales-sa.png');

INSERT INTO Almacen (ID_Almacen, Ubicacion, CapacidadV, CantidadV, IMGURL_Almacen)
VALUES (2, 'AV AVIACION 1172,La Victoria 15034, Peru', 20, 2, 'https://img10.naventcdn.com/avisos/resize/11/00/90/65/18/98/1200x1200/1101616768.jpg');

--insert para empresa
INSERT INTO Empresa (RUC, Dominio_Fiscal, Nombre)
VALUES (20611197099, 'Jr La Malva 195 Dpto 502C2 Monterrico Surco', 'Maxiauto SAC');

--insert Notaria (falta)

INSERT INTO Notaria (ID_Notaria, Nombre, Direccion)
VALUES (1, 'Notaria Gonzales Loli', 'Jiron Mariscal Miller 1701, Lince 15073');

INSERT INTO Notaria (ID_Notaria, Nombre, Direccion)
VALUES (2, 'Notaria Rosales Sepulveda', 'Av Juan de Arona 707, San Isidro 15046');

--insert Vendedor

INSERT INTO Vendedor (ID_Empleado, Telefono, Email, Nombre, Apellido, Salario, RUC, ID_Almacen)
VALUES (1, '987654321', 'JGomez@maxiauto.com', 'Juan', 'Gomez', 2500, 20611197099, 1);

INSERT INTO Vendedor (ID_Empleado, Telefono, Email, Nombre, Apellido, Salario, RUC, ID_Almacen)
VALUES (2, '987123456', 'MLopez@maxiauto.com', 'Maria', 'Lopez', 2200, 20611197099, 2);

INSERT INTO Vendedor (ID_Empleado, Telefono, Email, Nombre, Apellido, Salario, RUC, ID_Almacen)
VALUES (3, '987789012', 'CRodriguez@maxiauto.com', 'Carlos', 'Rodriguez', 2800, 20611197099, 1);

INSERT INTO Vendedor (ID_Empleado, Telefono, Email, Nombre, Apellido, Salario, RUC, ID_Almacen)
VALUES (4, '987345678', 'AMartinez@maxiauto.com', 'Ana', 'Martinez', 2300, 20611197099, 2);

--insert Banco  (falta interbank)

INSERT INTO Banco (ID_BANCO, Nombre, Ubicacion, IMGURL_Banco)
VALUES (1, 'Banco de la Nacion','Av. Arequipa 2740, San Isidro 15073', 'https://fastly.4sqi.net/img/general/600x600/s5Zyd6VFbawy6ysQFHH6gvi2GlbGqtphdRpdTaEWquE.jpg');

INSERT INTO Banco (ID_BANCO, Nombre, Ubicacion, IMGURL_Banco)
VALUES (2, 'BBVA Continental', 'Av. Republica de Panama 3055, San Isidro 15036', 'https://fastly.4sqi.net/img/general/600x600/75655714_pC50KYHXlyNEko8ocTexYB-WMhVC0oh0oA2Y76e9jWA.jpg');

INSERT INTO Banco (ID_BANCO, Nombre, Ubicacion, IMGURL_Banco)
VALUES (3, 'Scotiabank', 'C. Morelli 161, San Borja 15036', 'https://cdn.www.gob.pe/uploads/document/file/3387082/standard_Inician%20procedimiento%20sancionador%20contra%20Scotiabank%20%20y%20COBPER%C3%9A%20por%20humillar%20a%20usuario%20durante%20llamada%20de%20cobranza.jpg');

INSERT INTO Banco (ID_BANCO, Nombre, Ubicacion, IMGURL_Banco)
VALUES (4, 'Interbank', 'AV. AVIACION N 3385, MZ G2, LOTE 18, URB. LAS MAGNOLIAS, Av. Aviacion, Lima 15037', 'https://interbank.pe/documents/20124/326705/img-agencia-mobile%402x.jpg/fc50b1db-d5b8-c688-80b7-f0fa2af462eb?t=1643144198967');

--insert para vehiculos
INSERT INTO Vehiculo (NroChasis, Modelo, Placa, Estado, Anio, Precio, FechaIngreso, FechaSalida, ImgURL_Vehiculo, Kilometraje, Combustible, Condicion, Marca, Transmision, NroMotor, Color, ID_Almacen, RUC)
VALUES (123456789, 'Toyota Corolla', 'ABC123', 'Disponible', 2022, 25000.00, TO_DATE('2023-01-15', 'YYYY-MM-DD'), NULL, 'https://www.toyotaperu.com.pe/sites/default/files/CorollaHybrid-blanco_4.png', 5000, 1, 1, 'Toyota', 1, 987654, 'Azul', 1, 20611197099);

INSERT INTO Vehiculo (NroChasis, Modelo, Placa, Estado, Anio, Precio, FechaIngreso, FechaSalida, ImgURL_Vehiculo, Kilometraje, Combustible, Condicion, Marca, Transmision, NroMotor, Color, ID_Almacen, RUC)
VALUES (987654321, 'Honda CR-V', 'XYZ789', 'Disponible', 2021, 30000.00, TO_DATE('2023-02-20', 'YYYY-MM-DD'), NULL, 'https://d275w7g9tp258u.cloudfront.net/wp-content/uploads/2023/03/CRV_GRIS_1_png-1.png', 8000, 2, 1, 'Honda', 2, 123456, 'Negro', 2, 20611197099);

INSERT INTO Vehiculo (NroChasis, Modelo, Placa, Estado, Anio, Precio, FechaIngreso, FechaSalida, ImgURL_Vehiculo, Kilometraje, Combustible, Condicion, Marca, Transmision, NroMotor, Color, ID_Almacen, RUC)
VALUES (111222333, 'Ford Focus', 'LMN456', 'Vendido', 2020, 18000.00, TO_DATE('2023-03-10', 'YYYY-MM-DD'), TO_DATE('2023-03-15', 'YYYY-MM-DD'), 'https://www.gpas-cache.ford.com/guid/af32f338-114a-3c6b-b2c0-f32bf580f0ab.png', 6000, 1, 1, 'Ford', 1, 654321, 'Blanco', 1, 20611197099);

INSERT INTO Vehiculo (NroChasis, Modelo, Placa, Estado, Anio, Precio, FechaIngreso, FechaSalida, ImgURL_Vehiculo, Kilometraje, Combustible, Condicion, Marca, Transmision, NroMotor, Color, ID_Almacen, RUC)
VALUES (222333444, 'Chevrolet Cruze', 'OPQ789', 'Disponible', 2022, 27000.00, TO_DATE('2023-04-05', 'YYYY-MM-DD'), NULL, 'https://img.remediosdigitales.com/31ea35/2014-cruze-diesel-1/1366_2000.jpg', 7000, 2, 1, 'Chevrolet', 2, 789012, 'Gris', 2, 20611197099);

INSERT INTO Vehiculo (NroChasis, Modelo, Placa, Estado, Anio, Precio, FechaIngreso, FechaSalida, ImgURL_Vehiculo, Kilometraje, Combustible, Condicion, Marca, Transmision, NroMotor, Color, ID_Almacen, RUC)
VALUES (333444555, 'Volkswagen Golf', 'RST012', 'Disponible', 2023, 32000.00, TO_DATE('2023-05-20', 'YYYY-MM-DD'), NULL, 'https://www.motor.com.co/__export/1686157090159/sites/motor/img/2023/06/07/volkswagen_golf_r_333_limited_edition_01.jpg_458557307.jpg', 3000, 1, 1, 'Volkswagen', 1, 345678, 'Rojo', 1, 20611197099);

INSERT INTO Vehiculo (NroChasis, Modelo, Placa, Estado, Anio, Precio, FechaIngreso, FechaSalida, ImgURL_Vehiculo, Kilometraje, Combustible, Condicion, Marca, Transmision, NroMotor, Color, ID_Almacen, RUC)
VALUES (444555666, 'Nissan Sentra', 'UVW345', 'Vendido', 2021, 26000.00, TO_DATE('2023-06-15', 'YYYY-MM-DD'), TO_DATE('2023-06-20', 'YYYY-MM-DD'), 'https://fotos.perfil.com/2019/11/01/nissan-sentra-o-sylphy-800182.jpg', 5000, 2, 1, 'Nissan', 2, 901234, 'Plateado', 2, 20611197099);

INSERT INTO Vehiculo (NroChasis, Modelo, Placa, Estado, Anio, Precio, FechaIngreso, FechaSalida, ImgURL_Vehiculo, Kilometraje, Combustible, Condicion, Marca, Transmision, NroMotor, Color, ID_Almacen, RUC)
VALUES (555666777, 'Mazda CX-5', 'XYZ678', 'Disponible', 2023, 35000.00, TO_DATE('2023-07-10', 'YYYY-MM-DD'), NULL, 'https://derco-pe-prod.s3.amazonaws.com/images/versions/2022-07-20-MAZDA_NEWCX5_PRIMEMT.png', 2000, 1, 1, 'Mazda', 1, 567890, 'Negro', 1, 20611197099);

--insert para Clientes (juan martinez)

INSERT INTO Cliente (DNI, Email, Nombre, Apellido, Estatus, IntencionCompra, TiempoIngresoLead, TiempoSalidaLead, ID_Almacen, ID_Empleado)
VALUES (123456789, 'AGutierres@gmail.com', 'Ana', 'Gutierrez', 'Interesado', 3, TO_TIMESTAMP('2023-01-15 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), NULL, 1, 1);

INSERT INTO Cliente (DNI, Email, Nombre, Apellido, Estatus, IntencionCompra, TiempoIngresoLead, TiempoSalidaLead, ID_Almacen, ID_Empleado)
VALUES (987654321, 'JMartinez@gmail.com', 'Juan', 'Martinez', 'En proceso de decision', 4, TO_TIMESTAMP('2023-02-20 14:45:00', 'YYYY-MM-DD HH24:MI:SS'), NULL, 2, 2);

INSERT INTO Cliente (DNI, Email, Nombre, Apellido, Estatus, IntencionCompra, TiempoIngresoLead, TiempoSalidaLead, ID_Almacen, ID_Empleado)
VALUES (111222333, 'MRodriguez@gmail.com', 'Maria', 'Rodriguez', 'No interesado', 2, TO_TIMESTAMP('2023-03-10 11:20:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-03-15 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1, 3);

INSERT INTO Cliente (DNI, Email, Nombre, Apellido, Estatus, IntencionCompra, TiempoIngresoLead, TiempoSalidaLead, ID_Almacen, ID_Empleado)
VALUES (444555666, 'CLopez@gmail.com', 'Carlos', 'Lopez', 'Interesado', 5, TO_TIMESTAMP('2023-04-05 13:10:00', 'YYYY-MM-DD HH24:MI:SS'), NULL, 2, 4);

-- Insertar registros en TipoMantenimiento
INSERT INTO TipoMantenimiento (Tipo, Descripcion) VALUES (1, 'Nivel de liquido de frenos');
INSERT INTO TipoMantenimiento (Tipo, Descripcion) VALUES (2, 'Nivel de aceite');
INSERT INTO TipoMantenimiento (Tipo, Descripcion) VALUES (3, 'Nivel de refrigerante o agua');
INSERT INTO TipoMantenimiento (Tipo, Descripcion) VALUES (4, 'Ultimo cambio de aceite');
INSERT INTO TipoMantenimiento (Tipo, Descripcion) VALUES (5, 'Ultima sincronizacion');
INSERT INTO TipoMantenimiento (Tipo, Descripcion) VALUES (6, 'Ultima alineacion-balanceo');
INSERT INTO TipoMantenimiento (Tipo, Descripcion) VALUES (7, 'Ultimo cambio de llantas');

-- Insertar registros en Mantenimiento asociados a Vehiculos y Tipos de Mantenimiento
-- Vehiculo 1
INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (1, TO_DATE('2023-01-10', 'YYYY-MM-DD'), 123456789, 1);

INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (2, TO_DATE('2023-03-15', 'YYYY-MM-DD'), 123456789, 3);

INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (3, TO_DATE('2023-05-20', 'YYYY-MM-DD'), 123456789, 5);

-- Vehiculo 2
INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (4, TO_DATE('2023-02-05', 'YYYY-MM-DD'), 987654321, 2);

INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (5, TO_DATE('2023-04-10', 'YYYY-MM-DD'), 987654321, 4);

-- Vehiculo 3
INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (6, TO_DATE('2023-03-01', 'YYYY-MM-DD'), 111222333, 1);

INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (7, TO_DATE('2023-06-15', 'YYYY-MM-DD'), 111222333, 6);

-- Vehiculo 4
INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (8, TO_DATE('2023-02-15', 'YYYY-MM-DD'), 444555666, 3);

INSERT INTO Mantenimiento (ID_Mantenimiento, Fecha_Mantenimiento, NroChasis, Tipo)
VALUES (9, TO_DATE('2023-07-05', 'YYYY-MM-DD'), 444555666, 7);

SELECT * FROM VEHICULO;





commit;
