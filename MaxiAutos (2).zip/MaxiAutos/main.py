import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from flask import Flask, render_template, request, redirect,url_for,session,flash
from datetime import datetime
import cx_Oracle
from collections.abc import MutableSequence

app = Flask(__name__)

# Configura la clave secreta
app.secret_key = 'clave'

username = "USERDB"
password = "PASSWORD"
host = 'localhost'
port='1521'
connection_str = f"{username}/{password}@{host}:{port}/xe"

try:
    conn = cx_Oracle.connect(connection_str)
    print("Conexión exitosa")
except cx_Oracle.Error as err:
    print (f"Error de conexión {err}")

def consultar_tabla(query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        results = cursor.fetchall()

        conn.commit()
        return {"Data": results}
    except Exception as e:
        return {"error": str(e)}

def insertar_tabla(query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e

@app.route('/')
def index():
    return render_template('index.html')

#ingresar sesion
@app.route('/ingresarSesion', methods=['GET', 'POST'])
def ingresarSesion():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Realizar la autenticación aquí
        if autenticar_usuario(email, password):
            # Autenticación exitosa, guardar el password en la sesión
            session['password'] = password
            return redirect(url_for('indexEmpleados'))
        else:
            # Autenticación fallida, mostrar mensaje de error
            return render_template('ingresarSesion.html', message="Usuario o contraseña incorrectos", message_type="danger")

    return render_template('ingresarSesion.html')

# Asumiendo que tienes una tabla llamada Vendedor con campos Email e ID_Empleado
def autenticar_usuario(email, password):
    # Realiza la consulta SQL con COUNT
    query = f"SELECT COUNT(*) FROM Vendedor WHERE Email = '{email}' AND ID_Empleado = '{password}'"
    resultado = consultar_tabla(query)

    # Verifica si el COUNT es mayor que 0 (es decir, si se encontró al menos un usuario)
    if resultado.get("Data") and resultado["Data"][0][0] > 0:
        return True
    else:
        return False


@app.route('/indexEmpleado')
def indexEmpleados():
    return render_template('indexEmpleado.html')


@app.route('/registrarAsistencia', methods=['GET', 'POST'])
def registrarAsistencia():
    if request.method == 'POST':
        # Obtener datos del formulario
        dni_cliente = request.form['dniCliente']
        asistencia = request.form['asistencia']
        decision_compra = request.form['decisionCompra']
        
        # Verificar si el DNI del cliente existe en la tabla cita
        query_verificar_dni = f"SELECT COUNT(*) FROM cita WHERE dni = '{dni_cliente}'"
        result = consultar_tabla(query_verificar_dni)
        print(f"dni_cliente: {dni_cliente}")
        print(f"Result: {result}")
        print(f"decision_compra: {decision_compra}")
        print(f"asistencia: {asistencia}")
        
        if result.get("Data") and result["Data"][0][0] == 0:
            # DNI no existe en la tabla cita, mostrar error
            return render_template('registrarAsistencia.html', error_message="El DNI del cliente no existe en la tabla cita")
            # Resto del código para actualizar la base de datos según la elección del cliente
        else:
            if decision_compra == 'si':
                    # Actualizar estatus del cliente a "venta semicerrada"
                query_actualizar_estatus = f"UPDATE cliente SET estatus = 'venta semicerrada' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)
            if decision_compra == "no":
                    # Actualizar estatus del cliente a "no venta"
                query_actualizar_estatus = f"UPDATE cliente SET estatus = 'no venta' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)
            if asistencia == 'si':
                    # Actualizar estatus de la cita a "S"
                query_actualizar_estatus = f"UPDATE cita SET asistencia = 'S' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)
            if asistencia == "no":
                    # Actualizar estatus de la cita a "N"
                query_actualizar_estatus = f"UPDATE cita SET asistencia = 'N' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)

            return redirect(url_for('indexEmpleados'))  # Redirigir al mismo endpoint después de realizar las actualizaciones

    # Si el método no es POST, renderizar la página con el formulario
    return render_template('registrarAsistencia.html')


@app.route('/registrarCliente', methods=['POST'])
def registrarCliente():
    if request.method == 'POST':
        # Obtener datos del formulario
        dni = request.form['dni']
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        email = request.form['email']
        intencion_compra = request.form['intencionDeCompra']

        try:
            # Verificar si el DNI ya existe en la tabla cliente
            query_verificar_dni = f"SELECT COUNT(*) FROM cliente WHERE dni = '{dni}'"
            result = consultar_tabla(query_verificar_dni)

            query2 = f"SELECT COUNT(*) FROM cliente WHERE dni = '{dni}' and nombre = '{nombre}' and apellido = '{apellido}' and email = '{email}'"
            res2 = consultar_tabla(query2)



            if result2.get("Data") and result2["Data"][0][0] > 0:
                # DNI ya existe, mostrar mensaje de error
                query_actualizar_cliente = """
                                                UPDATE cliente
                                                SET
                                                    intencion_compra = :intencion_compra
                                                WHERE dni = :dni
                                            """
                cursor = conn.cursor()
                cursor.execute(query_actualizar_cliente, {
                    'nombre': nombre,
                    'apellido': apellido,
                    'email': email,
                    'dni': dni,
                    'intencion_compra': intencion_compra
                })
                conn.commit()
                return render_template('regitrarCita.html')

            elif result.get("Data") and result["Data"][0][0] > 0:
                return render_template('registrarCliente.html', error_message="El DNI ingresado no corresponde a ese nombre y apellido, vuelve a intentarlo")
            else:
                # DNI no existe, proceder con la inserción
                query_insertar_cliente = """
                    INSERT INTO cliente (nombre, apellido, email, dni, intencion_compra)
                    VALUES (:nombre, :apellido, :email, :dni, :intencion_compra)
                """

                cursor = conn.cursor()
                cursor.execute(query_insertar_cliente, {
                    'nombre': nombre,
                    'apellido': apellido,
                    'email': email,
                    'dni': dni,
                    'intencion_compra': intencion_compra
                })

                conn.commit()

                # Inserción exitosa
                return render_template('regitrarCita.html')

        except Exception as e:
            # Ocurrió un error durante la inserción
            conn.rollback()
            flash(f"Error durante el registro: {str(e)}")

        return redirect(url_for('index'))

    # Redirigir a la página principal si no es una solicitud POST
    return redirect(url_for('index'))












'''
def consultar_tabla(query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        results = cursor.fetchall()

        conn.commit()
        return {"Data": results}
    except Exception as e:
        return {"error": str(e)}


def consultar_tabla(query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        results = cursor.fetchall()

        conn.commit()
        return {"Data": results}
    except cx_Oracle.Error as e:
        error_message = f"Error de Oracle: {e}"
        print(error_message)
        return {"error": error_message}
    except Exception as e:
        error_message = f"Error desconocido: {e}"
        print(error_message)
        return {"error": error_message}


def printv():
    query = "select nrochasis from vehiculo"
    data = consultar_tabla(query)
    print(data)

def printv2():
    query = "SELECT * FROM vehiculo"
    data = consultar_tabla(query)
    
    if "Data" in data:
        for row in data["Data"]:
            print(row)
    else:
        print(f"Error: {data.get('error', 'Unknown error')}")

printv2()
'''


'''
DIALECT = 'oracle'
SQL_DRIVER = 'cx_oracle'
USERNAME = 'USERDB'  # Ingresa tu nombre de usuario
PASSWORD = 'PASSWORD'  # Ingresa tu contraseña
HOST = 'localhost'  # Ingresa el host de la base de datos Oracle
PORT = 1521  # Ingresa el número de puerto

ENGINE_PATH_WIN_AUTH = f'{DIALECT}+{SQL_DRIVER}://{USERNAME}:{PASSWORD}@{HOST}:{PORT}'
engine = create_engine(ENGINE_PATH_WIN_AUTH)
session_db = sessionmaker()
session_db.configure(bind=engine)



def read():
    conn = engine.connect()
    stmt = text("""
        SELECT * FROM VEHICULO WHERE NroChasis > 0
    """)
    results = conn.execute(stmt)
    return [dict(r) for r in results]


def imprimir():
    try:
        conn = engine.connect()
        stmt = text("""
            SELECT * FROM VEHICULO
        """)
        rs = [dict(r) for r in conn.execute(stmt)]
        for row in rs:
            for column, value in row.items():
                print(f"{column}: {value}")
            print("\n")  # Separador entre filas
    except Exception as e:
        print(f"Error: {e}")

# Llama a la función imprimir
imprimir()
'''
if __name__ == '__main__':
    app.run(debug=True)