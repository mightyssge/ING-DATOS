from flask import Flask, render_template, request, redirect, url_for
import cx_Oracle
from datetime import datetime
import random

app = Flask(__name__)

username = "USERDB"
password = "PASSWORD"
host = 'localhost'
port = '1521'
service_name = 'xe'
connection_str = f"{username}/{password}@{host}:{port}/{service_name}"

try:
    conn = cx_Oracle.connect(connection_str)
    print("Conexión exitosa")
except cx_Oracle.Error as err:
    print(f"Error de conexión {err}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/addTrans', methods=['GET', 'POST'])
def formulario_trans():
    if request.method == "POST":
        try:
            id_Transferencia = int(request.form['id_Transferencia'])
            numeroChasis = int(request.form['numeroChasis'])
            importe = obtener_precio_vehiculo(numeroChasis)
            fechaTransaccion_str = request.form['fechaTransaccion']
            fechaTransaccion = datetime.strptime(fechaTransaccion_str, '%Y-%m-%d')
            dni = int(request.form['dni'])
            banco = request.form['banco']
            id_banco = asignar_id_banco(banco)
            id_empleado = obtener_id_empleado()

            print((id_Transferencia, importe, fechaTransaccion_str, id_banco, dni, numeroChasis, id_empleado))

            with conn.cursor() as cursor:
                cursor.callproc('realizar_trans', [id_Transferencia, importe, fechaTransaccion, id_banco, dni, numeroChasis, id_empleado])
                print("Data registrada")
                conn.commit()

            return redirect(url_for('TransferenciaExitosa',
                                    id_Transferencia=id_Transferencia,
                                    importe=importe,
                                    fechaTransaccion_str=fechaTransaccion_str,
                                    id_banco=id_banco,
                                    dni=dni,
                                    numeroChasis=numeroChasis,
                                    id_empleado=id_empleado))
        except Exception as e:
            print(e)
            return redirect(url_for('formulario_trans'))

    return render_template('Cliente-11.html')

@app.route('/transfexitosa')
def TransferenciaExitosa():
    # Obtener los datos de la URL
    id_Transferencia = request.args.get('id_Transferencia')
    importe = request.args.get('importe')
    fechaTransaccion_str = request.args.get('fechaTransaccion_str')
    id_banco = request.args.get('id_banco')
    dni = request.args.get('dni')
    id_empleado = request.args.get('id_empleado')
    foto_banco = obtener_imgbanco(id_banco)
    nombre = obtener_nombre(dni)
    apellido = obtener_apellido(dni)

    return render_template('Cliente - 12.html',
                           id_Transferencia=id_Transferencia,
                           importe=importe,
                           fechaTransaccion_str=fechaTransaccion_str,
                           id_banco=id_banco,
                           dni=dni, id_empleado=id_empleado,
                           foto_banco=foto_banco,
                           nombre=nombre,
                           apellido=apellido)

@app.route('/actaDig')
def ActaDigital():
    id_Transferencia = request.args.get('id_Transferencia')

    # Consulta SQL para obtener información de TransferenciaBancaria
    query = "SELECT Importe, FechaTransaccion, ID_Banco, DNI, ID_Vehiculo, ID_Empleado FROM TransferenciaBancaria WHERE ID_TransfBanc = :id_Transferencia"

    with conn.cursor() as cursor:
        cursor.execute(query, {'id_Transferencia': id_Transferencia})
        result = cursor.fetchone()

        # Verificar si se encontraron resultados
        if result:
            # Asignar cada valor a una variable individual
            importe = result[0]
            fecha_transaccion = result[1]
            id_banco = result[2]
            dni = result[3]
            id_vehiculo = result[4]
            id_empleado = result[5]
            nombre = obtener_nombre(dni)
            apellido = obtener_apellido(dni)
            ubicacion_banco = obtener_ubibanco(id_banco)


            # Puedes hacer lo que quieras con estas variables, por ejemplo, pasarlas a una plantilla HTML
            return render_template('Cliente - 13.html', importe=importe, fecha_transaccion=fecha_transaccion,
                                   id_banco=id_banco, dni=dni, id_vehiculo=id_vehiculo, id_empleado=id_empleado)

    # Manejar el caso en que no se encuentren resultados
    return render_template('error.html')


def asignar_id_banco(banco):
    # Asignar valores según el banco
    if banco == "bancodenacion":
        return 1
    elif banco == "bbvacontinental":
        return 2
    elif banco == "scotiabank":
        return 3
    elif banco == "interbank":
        return 4

def obtener_ubibanco(id_banco):
    query = "SELECT ubicacion FROM Banco WHERE id_banco = :id_banco"
    with conn.cursor() as cursor:
        cursor.execute(query, {'id_banco': id_banco})
        result = cursor.fetchone()
        return result[0] if result else None


def obtener_precio_vehiculo(numero_chasis):
    query = "SELECT Precio FROM Vehiculo WHERE NroChasis = :numero_chasis"
    with conn.cursor() as cursor:
        cursor.execute(query, {'numero_chasis': numero_chasis})
        result = cursor.fetchone()
        return result[0] if result else None

def obtener_id_empleado():
    id_empleado = random.randint(1, 4)
    return id_empleado

def obtener_imgbanco(id_banco):
    query = "SELECT imgurl_banco FROM Banco WHERE id_banco = :id_banco"
    with conn.cursor() as cursor:
        cursor.execute(query, {'id_banco': id_banco})
        result = cursor.fetchone()
        return result[0] if result else None

def obtener_nombre(dni):
    query = "SELECT Nombre FROM Cliente WHERE DNI = :dni"
    with conn.cursor() as cursor:
        cursor.execute(query, {'dni': dni})
        result = cursor.fetchone()
        return result[0] if result else None

def obtener_apellido(dni):
    query = "SELECT Apellido FROM Cliente WHERE DNI = :dni"
    with conn.cursor() as cursor:
        cursor.execute(query, {'dni': dni})
        result = cursor.fetchone()
        return result[0] if result else None


print(obtener_ubibanco(1))
if __name__ == '__main__':
    app.run(debug=True, port=5000)
