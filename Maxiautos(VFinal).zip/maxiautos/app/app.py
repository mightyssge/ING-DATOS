from flask import Flask, render_template, request, redirect, url_for, session, flash
import cx_Oracle
from datetime import datetime, timedelta
from random import randint
import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from collections.abc import MutableSequence



app = Flask(__name__)
# Configura la clave secreta
app.secret_key = 'clave'



username = "USERDB"
password = "PASSWORD"
host = 'localhost'
port = '1521'
service_name = 'xe'
connection_str = f"{username}/{password}@{host}:{port}/{service_name}"

try:
    conn = cx_Oracle.connect(connection_str)
    print("Conexión exitosa")
except cx_Oracle.Error as err:
    print(f"Error de conexión {err}")

@app.route('/')
def index():
    return render_template('index.html')

#Alvaro
def consultar_tabla(query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        results = cursor.fetchall()

        conn.commit()
        return {"Data": results}
    except Exception as e:
        return {"error": str(e)}

def insertar_tabla(query):
    try:
        cursor = conn.cursor()
        cursor.execute(query)
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e


@app.route('/ingresarSesion', methods=['GET', 'POST'])
def ingresarSesion():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Realizar la autenticación aquí
        if autenticar_usuario(email, password):
            # Autenticación exitosa, guardar el password en la sesión
            session['password'] = password
            return redirect(url_for('indexEmpleados'))
        else:
            # Autenticación fallida, mostrar mensaje de error
            return render_template('ingresarSesion.html', message="Usuario o contraseña incorrectos", message_type="danger")

    return render_template('ingresarSesion.html')

def autenticar_usuario(email, password):
    # Realiza la consulta SQL con COUNT
    query = f"SELECT COUNT(*) FROM Vendedor WHERE Email = '{email}' AND ID_Empleado = '{password}'"
    resultado = consultar_tabla(query)

    # Verifica si el COUNT es mayor que 0 (es decir, si se encontró al menos un usuario)
    if resultado.get("Data") and resultado["Data"][0][0] > 0:
        return True
    else:
        return False


@app.route('/indexEmpleado')
def indexEmpleados():
    return render_template('indexEmpleado.html')

@app.route('/registrarAsistencia', methods=['GET', 'POST'])
def registrarAsistencia():
    if request.method == 'POST':
        # Obtener datos del formulario
        dni_cliente = request.form['dniCliente']
        asistencia = request.form['asistencia']
        decision_compra = request.form['decisionCompra']
        
        # Verificar si el DNI del cliente existe en la tabla cita
        query_verificar_dni = f"SELECT COUNT(*) FROM cita WHERE dni = '{dni_cliente}'"
        result = consultar_tabla(query_verificar_dni)
        print(f"dni_cliente: {dni_cliente}")
        print(f"Result: {result}")
        print(f"decision_compra: {decision_compra}")
        print(f"asistencia: {asistencia}")
        
        if result.get("Data") and result["Data"][0][0] == 0:
            # DNI no existe en la tabla cita, mostrar error
            return render_template('registrarAsistencia.html', error_message="El DNI del cliente no existe en la tabla cita")
            # Resto del código para actualizar la base de datos según la elección del cliente
        else:
            if decision_compra == 'si':
                    # Actualizar estatus del cliente a "venta semicerrada"
                query_actualizar_estatus = f"UPDATE cliente SET estatus = 'venta semicerrada' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)
            if decision_compra == "no":
                    # Actualizar estatus del cliente a "no venta"
                query_actualizar_estatus = f"UPDATE cliente SET estatus = 'no venta' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)
            if asistencia == 'si':
                    # Actualizar estatus de la cita a "S"
                query_actualizar_estatus = f"UPDATE cita SET asistencia = 'S' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)
            if asistencia == "no":
                    # Actualizar estatus de la cita a "N"
                query_actualizar_estatus = f"UPDATE cita SET asistencia = 'N' WHERE dni = '{dni_cliente}'"
                insertar_tabla(query_actualizar_estatus)

            return redirect(url_for('indexEmpleados'))  # Redirigir al mismo endpoint después de realizar las actualizaciones

    # Si el método no es POST, renderizar la página con el formulario
    return render_template('registrarAsistencia.html')



#Fabrizio

@app.route('/addTrans', methods=['GET', 'POST'])
def formulario_trans():
    if request.method == "POST":
        try:
            id_Transferencia = int(request.form['id_Transferencia'])
            numeroChasis = int(request.form['numeroChasis'])
            estado_numerico = obtener_estado_numerico(numeroChasis)
            if estado_numerico == 0:
                raise Exception("Error: El vehículo ya ha sido vendido.")
            importe = obtener_precio_vehiculo(numeroChasis)
            fechaTransaccion_str = request.form['fechaTransaccion']
            fechaTransaccion = datetime.strptime(fechaTransaccion_str, '%Y-%m-%d')
            dni = int(request.form['dni'])
            banco = request.form['banco']
            id_banco = asignar_id_banco(banco)
            id_empleado = obtener_id_empleado(dni)

            # Realizar el primer procedimiento
            with conn.cursor() as cursor:
                cursor.callproc('realizar_trans', [id_Transferencia, importe, fechaTransaccion, id_banco, dni, numeroChasis, id_empleado])
                conn.commit()

            # Generar la fecha de emisión para ACTAENTREGA (3 días después de la fecha de transferencia)
            fecha_emision = fechaTransaccion + timedelta(days=3)
            ruc = 20611197099

            # Generar un número aleatorio para id_notaria (cambiar según tus necesidades)
            id_notaria = randint(1, 2)

            # Realizar el segundo procedimiento para insertar en ACTAENTREGA
            with conn.cursor() as cursor:
                cursor.callproc('insertar_actaentrega', [id_Transferencia, fecha_emision, dni, id_notaria, numeroChasis, ruc])
                conn.commit()

            return redirect(url_for('TransferenciaExitosa',
                                    id_Transferencia=id_Transferencia,
                                    importe=importe,
                                    fechaTransaccion_str=fechaTransaccion_str,
                                    id_banco=id_banco,
                                    dni=dni,
                                    numeroChasis=numeroChasis,
                                    id_empleado=id_empleado))
        except Exception as e:
            print(e)
            return redirect(url_for('formulario_trans',  error=e))

    return render_template('Cliente-11.html')


@app.route('/transfexitosa')
def TransferenciaExitosa():
    id_Transferencia = request.args.get('id_Transferencia')
    importe = request.args.get('importe')
    fechaTransaccion_str = request.args.get('fechaTransaccion_str')
    id_banco = request.args.get('id_banco')
    dni = request.args.get('dni')
    id_empleado = request.args.get('id_empleado')
    foto_banco = obtener_imgbanco(id_banco)
    nombre = obtener_nombre(dni)
    apellido = obtener_apellido(dni)

    return render_template('Cliente - 12.html',
                           id_Transferencia=id_Transferencia,
                           importe=importe,
                           fechaTransaccion_str=fechaTransaccion_str,
                           id_banco=id_banco,
                           dni=dni, id_empleado=id_empleado,
                           foto_banco=foto_banco,
                           nombre=nombre,
                           apellido=apellido)

@app.route('/actaDig')
def actaDigital():
    return render_template('Cliente - 13.html')


def obtener_nombre_apellido_vendedor(id_empleado):
    # Assuming you have a connection object named 'conn'
    with conn.cursor() as cursor:
        # Query to get the Nombre and Apellido of the Vendedor
        query = """
        SELECT Nombre, Apellido
        FROM Vendedor
        WHERE ID_Empleado = :id_empleado
        """
        cursor.execute(query, {'id_empleado': id_empleado})
        result = cursor.fetchone()

        # Check if the result is not None
        if result:
            nombre = result[0]
            apellido = result[1]
            return f"{nombre} {apellido}"

    # Return None if the query didn't return any result
    return None

def ubicar_estado(id_vehiculo):
    query = "SELECT Estado FROM Vehiculo WHERE NroChasis = :nrochasis"
    with conn.cursor() as cursor:
        cursor.execute(query, {'nrochasis': id_vehiculo})
        result = cursor.fetchone()
        return result[0] if result else None


def obtener_estado_numerico(id_vehiculo):
    query = "SELECT Estado FROM Vehiculo WHERE NroChasis = :nrochasis"
    with conn.cursor() as cursor:
        cursor.execute(query, {'nrochasis': id_vehiculo})
        result = cursor.fetchone()
        if result:
            estado = result[0]
            return 0 if estado == "Vendido" else 1
        else:
            return None

    

def asignar_id_banco(banco):
    # Asignar valores según el banco
    if banco == "bancodenacion":
        return 1
    elif banco == "bbvacontinental":
        return 2
    elif banco == "scotiabank":
        return 3
    elif banco == "interbank":
        return 4

def obtener_ubibanco(id_banco):
    query = "SELECT ubicacion FROM Banco WHERE id_banco = :id_banco"
    with conn.cursor() as cursor:
        cursor.execute(query, {'id_banco': id_banco})
        result = cursor.fetchone()
        return result[0] if result else None


def obtener_precio_vehiculo(numero_chasis):
    query = "SELECT Precio FROM Vehiculo WHERE NroChasis = :numero_chasis"
    with conn.cursor() as cursor:
        cursor.execute(query, {'numero_chasis': numero_chasis})
        result = cursor.fetchone()
        return result[0] if result else None

def obtener_id_empleado(dni):
    query = "SELECT id_empleado FROM Cita WHERE dni = :dni"
    with conn.cursor() as cursor:
        cursor.execute(query, {'dni': dni})
        result = cursor.fetchone()
        return result[0] if result else None


def obtener_imgbanco(id_banco):
    query = "SELECT imgurl_banco FROM Banco WHERE id_banco = :id_banco"
    with conn.cursor() as cursor:
        cursor.execute(query, {'id_banco': id_banco})
        result = cursor.fetchone()
        return result[0] if result else None

def obtener_nombre(dni):
    query = "SELECT Nombre FROM Cliente WHERE DNI = :dni"
    with conn.cursor() as cursor:
        cursor.execute(query, {'dni': dni})
        result = cursor.fetchone()
        return result[0] if result else None

def obtener_apellido(dni):
    query = "SELECT Apellido FROM Cliente WHERE DNI = :dni"
    with conn.cursor() as cursor:
        cursor.execute(query, {'dni': dni})
        result = cursor.fetchone()
        return result[0] if result else None


#Alejandro
# Función para obtener detalles del almacén desde la base de datos
def obtener_almacen_por_id(id_almacen):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Almacen WHERE ID_Almacen = :id", {"id": id_almacen})
    almacen = cursor.fetchone()
    cursor.close()
    return almacen

# Ruta para mostrar los vehículos
@app.route('/cliente-2')
def cliente_2():
    # Obtener vehículos desde la base de datos (reemplazar con tu lógica)
    vehiculos = obtener_vehiculos_desde_bd()
    
    return render_template('Cliente - 2.html', vehiculos=vehiculos)

# Ruta para mostrar detalles del vehículo seleccionado
@app.route('/cliente-3')
def cliente_3():
    # Obtener parámetros de la URL
    modelo = request.args.get('modelo')
    anio = request.args.get('anio')
    precio = request.args.get('precio')
    kilometraje = request.args.get('kilometraje')
    local = request.args.get('local')
    
    almacen = obtener_almacen_por_id(local)

    # Agregar más parámetros según sea necesario
    # Redirigir a Cliente - 3.html con los parámetros
    return render_template('Cliente - 3.html', modelo=modelo, anio=anio, precio=precio, 
                           kilometraje=kilometraje, local=almacen, imagen=request.args.get('imagen'))


# Función para obtener vehículos desde la base de datos
def obtener_vehiculos_desde_bd():
    # Ejemplo de consulta (reemplazar con tu consulta real)
    cursor = conn.cursor()
    cursor.execute("SELECT Marca, Modelo, Anio, Precio, Kilometraje, Combustible, Transmision, Id_almacen, ImgURL_Vehiculo FROM Vehiculo WHERE ROWNUM <= 7")
    vehiculos = [dict(zip([column[0] for column in cursor.description], row)) for row in cursor.fetchall()]
    cursor.close()

    return vehiculos
#alvaro2

@app.route('/registrarCliente', methods=[ 'GET' ,'POST'])
def registrarCliente():
    if request.method == 'POST':
        # Obtener datos del formulario
        dni = request.form['dni']
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        email = request.form['email']
        intencioncompra = request.form['intencionDeCompra']

        try:
            # Verificar si el DNI ya existe en la tabla cliente
            query_verificar_dni = f"SELECT COUNT(*) FROM cliente WHERE dni = '{dni}'"
            result = consultar_tabla(query_verificar_dni)

            query2 = f"SELECT COUNT(*) FROM cliente WHERE dni = '{dni}' and nombre = '{nombre}' and apellido = '{apellido}' and email = '{email}'"
            res2 = consultar_tabla(query2)



            if res2.get("Data") and res2["Data"][0][0] > 0:
                # DNI ya existe, mostrar mensaje de error
                query_actualizar_cliente = """
                                                UPDATE cliente
                                                SET
                                                    intencioncompra = :intencioncompra
                                                WHERE dni = :dni
                                            """
                cursor = conn.cursor()
                cursor.execute(query_actualizar_cliente, {
                    'nombre': nombre,
                    'apellido': apellido,
                    'email': email,
                    'dni': dni,
                    'intencioncompra': intencioncompra
                })
                conn.commit()
                return render_template('regitrarCita.html')

            elif result.get("Data") and result["Data"][0][0] > 0:
                return render_template('registrarCliente.html', error_message="El DNI ingresado no corresponde a ese nombre y apellido, vuelve a intentarlo")
            else:
                # DNI no existe, proceder con la inserción
                query_insertar_cliente = """
                    INSERT INTO cliente (nombre, apellido, email, dni, intencioncompra)
                    VALUES (:nombre, :apellido, :email, :dni, :intencioncompra)
                """

                cursor = conn.cursor()
                cursor.execute(query_insertar_cliente, {
                    'nombre': nombre,
                    'apellido': apellido,
                    'email': email,
                    'dni': dni,
                    'intencioncompra': intencioncompra
                })

                conn.commit()

                # Inserción exitosa
                return render_template('registrarCita.html')

        except Exception as e:
            # Ocurrió un error durante la inserción
            conn.rollback()
            print(f"Error durante el registro: {str(e)}")

        return redirect(url_for('index'))
    else:
        return render_template('registrarCliente.html')

@app.route('/registrarCita')
def registrarCita():
    return render_template('registerCita.html')

@app.route('/citaSacada')
def citaSacada():
    return render_template('Cliente - 6.html')


if __name__ == '__main__':
    app.run(debug=True, port=5000)
